// insecure-protocol — substrate honesty (network security)
// Using HTTP instead of HTTPS, FTP, Telnet, or other unencrypted protocols
// is a lie about security — the code pretends to transmit safely when
// anyone on the path can read it. WiFi credentials sent over HTTP,
// API calls to http:// endpoints, and FTP file transfers are all
// the code claiming "this is secure" when it's plaintext on the wire.

import { SENSITIVE_SNIPPET } from '../redaction.js'

const HTTP_URL = /https?:\/\/(?!localhost|127\.0\.0\.1|0\.0\.0\.0|example\.com|schemas\.)[a-z0-9.-]+\.[a-z]{2,}/i
const HTTP_ONLY = /\bhttp:\/\/(?!localhost|127\.0\.0\.1|0\.0\.0\.0)/i
const FTP_URL = /\bftp:\/\//i
const TELNET = /\btelnet\b/i
const WS_INSECURE = /\bws:\/\//i // unencrypted WebSocket
// When http:// appears inside a startsWith/includes/matches/test call, the code
// is CHECKING for insecure URLs, not USING them. Skip those lines. Also skip
// comment-only lines that mention http:// in annotation. The bell needs to see
// the difference between checking for a lie and telling one (castle 0064).
const SECURE_CHECK = /(?:startsWith|includes|matches|\.test)\s*\(\s*['"`]https?:\/\//i

export const insecureProtocol = {
  id: 'insecure-protocol',
  title: 'Insecure protocol used for network communication',
  confidence: 'medium-high',
  doctrine: 'substrate-honesty',
  principle: 2,
  langs: ['js'],
  redactSnippet: true,
  detect(content, lines) {
    const hits = []
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i]
      if (HTTP_ONLY.test(l) && !l.includes('://localhost') && !l.includes('://127.') && !SECURE_CHECK.test(l) && !/^\s*\/\//.test(l)) {
        hits.push({
          line: i + 1,
          message: 'HTTP (not HTTPS) used for network communication — data is transmitted in plaintext',
          snippet: SENSITIVE_SNIPPET,
        })
        continue
      }
      if (FTP_URL.test(l)) {
        hits.push({
          line: i + 1,
          message: 'FTP protocol used — credentials and data transmitted in plaintext',
          snippet: SENSITIVE_SNIPPET,
        })
        continue
      }
      if (TELNET.test(l)) {
        hits.push({
          line: i + 1,
          message: 'Telnet protocol referenced — unencrypted remote access, credentials in plaintext',
          snippet: SENSITIVE_SNIPPET,
        })
        continue
      }
      if (WS_INSECURE.test(l) && !l.includes('localhost') && !l.includes('127.') && !SECURE_CHECK.test(l) && !/^\s*\/\//.test(l)) {
        hits.push({
          line: i + 1,
          message: 'WebSocket (ws://) used without TLS — data transmitted in plaintext',
          snippet: SENSITIVE_SNIPPET,
        })
      }
    }
    return hits
  },
}
